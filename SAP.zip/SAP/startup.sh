nohup /usr/local/python/bin/python3 /data/python/SAP/manage.py runserver 0.0.0.0:80 >>asset.log &
