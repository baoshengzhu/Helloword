# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse,HttpResponse
from models import  *
import json
import logging
logger = logging.getLogger("django")

def user_info(request):
    ip_addr = request.META['REMOTE_ADDR']
    user_ua = request.META['HTTP_USER_AGENT']

    user_obj = UserIPInfo.objects.filter(ip=ip_addr)
    if not user_obj:
        res = UserIPInfo.objects.create(ip=ip_addr)
        ip_addr_id = res.id
    else:
        logger.info("%s already exists!"%(ip_addr))
        ip_addr_id=user_obj[0].id

    BrowseInfo.objects.create(useragent = user_ua,userip_id=ip_addr_id)

    result = {"STATUS":"success",
              "INFO":"User_info",
              "IP":ip_addr,
              "UA":user_ua
    }

    return  HttpResponse(json.dumps(result),content_type="application/json")



def user_history(request):
    ip_list = UserIPInfo.objects.all()
    infos = {}
    for item in ip_list:
        infos[item.ip] = [b_obj.useragent for b_obj in BrowseInfo.objects.filter(userip=item)]

    result = {
        "STATUS":"success",
        "INFO":infos,
    }
    logger.info("hello already result")
    return HttpResponse(json.dumps(result), content_type="application/json")